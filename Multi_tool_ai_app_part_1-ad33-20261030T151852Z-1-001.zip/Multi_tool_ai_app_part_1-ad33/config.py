GROQ_API_KEY = "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"

GROQ_MODELS = [
    "llama-3.1-8b-instant",
    "llama-3.3-70b-versatile"
]