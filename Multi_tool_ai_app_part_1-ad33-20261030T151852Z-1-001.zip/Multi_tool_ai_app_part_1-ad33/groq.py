
import config
from openai import OpenAI

GROQ_URL = "https://api.groq.com/openai/v1"

MODELS = [
    "openai/gpt-oss-20b",
    "openai/gpt-oss-120b"
]


def generate_response(prompt, temperature=0.3, max_tokens=512):

    key = getattr(config, "GROQ_API_KEY", None)

    if not key:
        return "Error: GROQ_API_KEY missing in config.py"

    client = OpenAI(
        api_key=key,
        base_url=GROQ_URL
    )

    last_error = None

    for model in MODELS:

        try:

            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                max_completion_tokens=max_tokens
            )

            return response.choices[0].message.content or "No response generated."

        except Exception as e:

            last_error = e

    return (
        f"Groq model failed.\n"
        f"Models tried: {MODELS}\n"
        f"Error: {type(last_error).__name__}: {last_error}"
    )
