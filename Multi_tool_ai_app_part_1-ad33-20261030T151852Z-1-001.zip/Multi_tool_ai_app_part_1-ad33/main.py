
import io
import streamlit as st

# Import Groq response function
from groq import generate_response


# ==========================================
# MATH SYSTEM PROMPT
# ==========================================

MATH_SYSTEM = """
You are a Math Mastermind.

Solve problems with:
1. Clear step-by-step explanations.
2. Correct mathematical notation.
3. Simple explanations for students.
4. A final answer.
5. Verification whenever possible.
"""


# ==========================================
# CHAT DESIGN
# ==========================================

CHAT_CSS = """
<style>
.wrap {
    max-height: 520px;
    overflow-y: auto;
    padding-right: 6px;
}

.card {
    border: 1px solid #e6e6e6;
    background: white;
    border-radius: 10px;
    padding: 14px 16px;
    margin: 10px 0;
    box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}

.q {
    font-weight: bold;
    color: #0a6ebd;
    margin-bottom: 8px;
}

.meta {
    display: inline-block;
    background: #FF9800;
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    margin-left: 8px;
}

.a {
    white-space: pre-wrap;
    color: #333;
    line-height: 1.5;
}
</style>
"""


# ==========================================
# EXPORT CONVERSATION
# ==========================================

def export_txt(history):

    txt = ""

    for i, h in enumerate(history, 1):
        txt += f"Q{i}: {h['question']}\n"
        txt += f"A{i}: {h['answer']}\n\n"

    bio = io.BytesIO(txt.encode("utf-8"))

    return bio


# ==========================================
# AI TEACHING ASSISTANT
# ==========================================

def teaching_answer(q):

    return generate_response(
        q,
        temperature=0.3,
        max_tokens=1024
    )


def run_ai_teaching_assistant():

    st.title("🤖 AI Teaching Assistant")

    st.write("Ask any educational question.")

    st.session_state.setdefault("history_ata", [])

    c1, c2 = st.columns([1, 2])

    if c1.button("🧹 Clear", key="c_ata"):

        st.session_state.history_ata = []

        st.rerun()

    if st.session_state.history_ata:

        c2.download_button(
            "📄 Export",
            export_txt(st.session_state.history_ata),
            "AI_Teaching_Assistant_Conversation.txt",
            "text/plain"
        )

    q = st.text_input(
        "Enter your question:",
        key="q_ata"
    )

    if st.button("Ask", key="a_ata"):

        if not q.strip():

            st.warning("Please enter a question.")

        else:

            with st.spinner("Thinking..."):

                answer = teaching_answer(q.strip())

                st.session_state.history_ata.append({
                    "question": q.strip(),
                    "answer": answer
                })

            st.rerun()

    if not st.session_state.history_ata:
        return

    st.markdown(CHAT_CSS, unsafe_allow_html=True)

    html = '<div class="wrap">'

    for i, qa in enumerate(st.session_state.history_ata, 1):

        html += f"""
        <div class="card">
            <div class="q">Q{i}: {qa['question']}</div>
            <div class="a">{qa['answer']}</div>
        </div>
        """

    st.markdown(html + "</div>", unsafe_allow_html=True)


# ==========================================
# MATH MASTERMIND
# ==========================================

def math_answer(q, level):

    prompt = f"""
    {MATH_SYSTEM}

    Difficulty Level: {level}

    Math Problem: {q}
    """

    return generate_response(
        prompt,
        temperature=0.1,
        max_tokens=1024
    )


def run_math_mastermind():

    st.title("🧮 Math Mastermind")

    st.write("Enter a mathematical problem to get a solution.")

    st.session_state.setdefault("history_mm", [])

    st.session_state.setdefault("k_mm", 0)

    c1, c2 = st.columns([1, 2])

    if c1.button("🧹 Clear", key="c_mm"):

        st.session_state.history_mm = []

        st.rerun()

    if st.session_state.history_mm:

        c2.download_button(
            "📄 Export",
            export_txt(st.session_state.history_mm),
            "Math_Mastermind_Solutions.txt",
            "text/plain"
        )

    with st.form("mm_form", clear_on_submit=True):

        q = st.text_area(
            "Math problem:",
            height=100,
            key=f"mm_{st.session_state.k_mm}"
        )

        a, b = st.columns([3, 1])

        go = a.form_submit_button(
            "Solve",
            use_container_width=True
        )

        level = b.selectbox(
            "Level",
            ["Basic", "Intermediate", "Advanced"],
            index=1
        )

        if go:

            if not q.strip():

                st.warning("Please enter a math problem.")

            else:

                with st.spinner("Solving your problem..."):

                    answer = math_answer(q.strip(), level)

                st.session_state.history_mm.insert(
                    0,
                    {
                        "question": q.strip(),
                        "answer": answer,
                        "difficulty": level
                    }
                )

                st.session_state.k_mm += 1

                st.rerun()

    if not st.session_state.history_mm:
        return

    st.markdown(CHAT_CSS, unsafe_allow_html=True)

    html = '<div class="wrap">'

    for i, qa in enumerate(st.session_state.history_mm, 1):

        html += f"""
        <div class="card">
            <div class="q">
                Q{i}: {qa['question']}
                <span class="meta">{qa['difficulty']}</span>
            </div>
            <div class="a">{qa['answer']}</div>
        </div>
        """

    st.markdown(html + "</div>", unsafe_allow_html=True)


# ==========================================
# SAFE AI IMAGE GENERATOR
# ==========================================

def run_safe_ai_image_generator():

    st.title("🎨 Safe AI Image Generator")

    st.info(
        "Image Generator Part 2 has not been added yet. "
        "Add your Part 2 code to enable this feature."
    )


# ==========================================
# MAIN APPLICATION
# ==========================================

def main():

    st.set_page_config(
        page_title="Multi Tool AI App",
        page_icon="🤖",
        layout="wide"
    )

    st.sidebar.title("🤖 Multi Tool AI App")

    opt = st.sidebar.selectbox(
        "Choose an AI Tool",
        [
            "AI Teaching Assistant",
            "Math Mastermind",
            "Safe AI Image Generator"
        ]
    )

    if opt == "AI Teaching Assistant":

        run_ai_teaching_assistant()

    elif opt == "Math Mastermind":

        run_math_mastermind()

    else:

        run_safe_ai_image_generator()


# ==========================================
# START APPLICATION
# ==========================================

if __name__ == "__main__":

    main()
